SPM JP Crash Fix v1.0 by JohnP55

How it works:
- Fixes a crash in DVDMgrReadAsync where under rare interrupt timing, a read could be triggered twice, causing a panic crash in DVDFS.c

How to install:
- Move the "private" folder to the root of your SD card
- Go to vWii
- Navigate to Wii Options -> Save Data
- Navigate to SD Card
- Copy the SPM save file to your console

How to use:
Same as Practice Codes, enter the REL Loader save file, navigate to items, and the game will reboot with the crash fix enabled. From there, you can start playing without fear of randomly crashing.

Credits:
https://github.com/SeekyCt/spm-rel-loader
https://github.com/SeekyCt/spm-save-exploit
https://github.com/SeekyCt/spm-headers